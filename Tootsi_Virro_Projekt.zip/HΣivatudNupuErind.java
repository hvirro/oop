public class HõivatudNupuErind extends RuntimeException {
    public HõivatudNupuErind(String message) {
        super(message);
    }
}
