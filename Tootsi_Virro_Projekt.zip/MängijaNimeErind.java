public class MängijaNimeErind extends RuntimeException {
    public MängijaNimeErind(String message) {
        super(message);
    }
}
